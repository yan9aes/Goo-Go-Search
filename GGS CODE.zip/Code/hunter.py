import math
from .shot import*
from PPlay.sound import*
H_TIMER = 2
class Hunter:
    def __init__(self, pos_x=0, pos_y=0, flight_x=None, flight_y=None, s_vol = 100, path = "Assets/Sprites/enemies_1"):
        self.shot_sound = Sound("Assets/Sounds/shot.ogg")
        self.shot_sound.set_volume(s_vol)
        self.images = []
        self.curr_frame = 0
        self.images.append(Sprite(path+str(self.curr_frame)+".png"))
        self.images.append(Sprite(path+str(self.curr_frame+1)+".png"))
        self.image = self.images[self.curr_frame]
        self.image.x = (pos_x*32+(16-self.image.width/2))
        self.image.y = (pos_y*32+(16-self.image.height/2))
        self.flight_x = []
        self.flight_y = []
        self.flight_len = len(flight_x)
        self.currf = 0
        self.speed = 128
        self.shot_speed = 320
        self.range = 200
        self.center_x = self.image.x +(self.image.width/2)
        self.center_y = self.image.y +(self.image.height/2)
        self.timer = 0
        self.frame_timer = 0.1
        for i in range(len(flight_x)):
            self.flight_x.append((flight_x[i]*32)+(16-self.image.width/2))
        for i in range(len(flight_y)):
            self.flight_y.append((flight_y[i]*32)+(16-self.image.height/2))
    def flight(self, dt):
        self.frame_timer-=dt
        if(self.frame_timer <0):
            self.frame_timer = 0.1
            self.curr_frame = (self.curr_frame+1)%2
            nx = self.image.x
            ny = self.image.y
            self.image = self.images[self.curr_frame]
            self.image.x = nx
            self.image.y = ny
        if(self.image.x == self.flight_x[self.currf] and self.image.y == self.flight_y[self.currf]):
            self.currf += 1
        if(self.currf >= self.flight_len):
            self.currf = 0
        else:
            move = self.speed*dt
            distx = abs(self.image.x - self.flight_x[self.currf])
            disty = abs(self.image.y - self.flight_y[self.currf])
            aux = min(distx, move)
            if(self.image.x > self.flight_x[self.currf]):
                self.image.move_x(-aux)
            else:
                self.image.move_x(aux)
            aux = min(disty, move)
            if(self.image.y > self.flight_y[self.currf]):
                self.image.move_y(-aux)
            else:
                self.image.move_y(aux)
    def detect(self, player_center_x, player_center_y):
        vel_x = player_center_x-self.center_x
        vel_y = player_center_y-self.center_y
        norma = math.sqrt((vel_x*vel_x)+(vel_y*vel_y))
        if(norma<= self.range):
            alpha = (self.shot_speed/norma)
            vel_x *= alpha
            vel_y *= alpha
            return((vel_x, vel_y))
        return((0,0))
    def update(self, pcx, pcy, dt, bullets):
        self.center_x = self.image.x +(self.image.width/2)
        self.center_y = self.image.y +(self.image.height/2)
        self.timer += dt
        if(self.timer >= H_TIMER):
            coord = self.detect(pcx, pcy)
            if(coord[0] != 0 or coord[1] != 0):
                self.timer = 0
                bullets.append(Shot(self.center_x, self.center_y, coord[0], coord[1]))
                self.shot_sound.play()
                self.flight(dt)
                return True
        self.flight(dt)
        return False