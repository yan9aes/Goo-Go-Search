#tipos definidos abaixo
T_BASE = 1
T_GELO = 2
T_MOLA_DIR = 3
T_TIRO_CIM = 4
T_TIRO_DIR = 5
T_TIRO_BAI = 6
T_TIRO_ESQ = 7
T_FASE = 8
T_MOLA_ESQ = 9

T_TIMER = 3
T_VEL = 320

from .shot import *
from PPlay.sound import*
class Tile:
    def __init__(self, tipo = 1, s_vol = 100, path = "Assets/Sprites/tiles_"):
        self.image = Sprite(path + str(tipo) + ".png")
        self.tipo = tipo
        self.timer = 0
        self.velx = 0
        self.vely = 0
        if(tipo == T_TIRO_CIM):
            self.vely = -T_VEL
        elif(tipo == T_TIRO_DIR):
            self.velx = T_VEL
        elif(tipo == T_TIRO_BAI):
            self.vely = T_VEL
        elif(tipo == T_TIRO_ESQ):
            self.velx = -T_VEL
        if(self.tipo == T_TIRO_CIM or self.tipo == T_TIRO_DIR or self.tipo == T_TIRO_BAI or self.tipo == T_TIRO_ESQ):
            self.shot_sound = Sound("Assets/Sounds/shot.ogg")
            self.shot_sound.set_volume(s_vol)
    def update(self, dt, bullets):
        if(self.tipo == T_TIRO_CIM or self.tipo == T_TIRO_DIR or self.tipo == T_TIRO_BAI or self.tipo == T_TIRO_ESQ):
            self.timer += dt
            if(self.timer >= T_TIMER):
                self.timer = 0
                if(self.tipo == T_TIRO_CIM):
                    bullets.append(Shot(self.image.x+(self.image.width/2), self.image.y, self.velx, self.vely, "vt_shot.png"))
                elif(self.tipo == T_TIRO_BAI):
                    bullets.append(Shot(self.image.x+(self.image.width/2), self.image.y+self.image.height, self.velx, self.vely, "vt_shot.png"))
                elif(self.tipo == T_TIRO_ESQ):
                    bullets.append(Shot(self.image.x, self.image.y+(self.image.height/2), self.velx, self.vely, "ht_shot.png"))
                elif(self.tipo == T_TIRO_DIR):
                    bullets.append(Shot(self.image.x+self.image.width, self.image.y+(self.image.height/2), self.velx, self.vely, "ht_shot.png"))
                self.shot_sound.play()