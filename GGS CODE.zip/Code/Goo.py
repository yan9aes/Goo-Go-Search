#tipos definidos abaixo
T_BASE = 1
T_GELO = 2
T_MOLA_DIR = 3
T_TIRO_CIM = 4
T_TIRO_DIR = 5
T_TIRO_BAI = 6
T_TIRO_ESQ = 7
T_FASE = 8
T_MOLA_ESQ = 9

S_JUMPING = 1
S_BACKING = 2
S_QUICADO = 3

import math
import random
from PPlay.window import *
from PPlay.gameimage import *
from PPlay.sprite import *
from PPlay.sound import *

DELAY = 0.1


class Player:
    def __init__(self, pos_x = 0, pos_y = 0, sound_vol = 100, path = "Assets/Sprites/slime_"):
        self.shift = False
        self.j_sound = Sound("Assets/Sounds/jump.ogg")
        self.j_sound.set_volume(sound_vol*0.5)
        self.path = path
        self.image = Sprite(path + "bai" + ".png")
        self.image.x = pos_x
        self.image.y = pos_y
        self.hitbox = Sprite("Assets/Sprites/hitbox.png")
        self.sbox = Sprite("Assets/Sprites/19sbox.png")
        self.state = 0
        self.jump_speed = 1000
        self.movex = 0
        self.movey = 0
        self.timer = -DELAY*5
        self.quica_timer = DELAY
        self.delay = DELAY
        self.center_x = self.image.x +(self.image.width/2)
        self.center_y = self.image.y +(self.image.height/2)
        self.hitbox.x = self.center_x-(self.hitbox.width/2)
        self.hitbox.y = self.center_y-(self.hitbox.height/2)
        self.coll = 0
        self.backspeed = 0.1
        self.slide_speed = 0.4
        self.sbox.x = self.center_x-(self.sbox.width/2)
        self.sbox.y = self.center_y-(self.sbox.height/2)
        
    def player_update(self, mouse, keyboard, dt, tiles = None, enemy_coll = False):
        self.center_x = self.image.x +(self.image.width/2)
        self.center_y = self.image.y +(self.image.height/2)
        self.hitbox.x = self.center_x-(self.hitbox.width/2)
        self.hitbox.y = self.center_y-(self.hitbox.height/2)
        self.sbox.x = self.center_x-(self.sbox.width/2)
        self.sbox.y = self.center_y-(self.sbox.height/2)
        self.quica_timer+= dt
        if(self.state == 0):
            self.movex = 0
            self.movey = 0
            self.timer +=dt
            if(mouse.is_button_pressed(1) and self.timer >= self.delay):
                self.state = S_JUMPING
                x, y = mouse.get_position()
                self.movex, self.movey = self.player_jump(x,y)
                self.j_sound.play()
        else:
            self.timer = 0
        if(self.quica_timer >= DELAY and self.state == S_QUICADO):
            self.quica_timer = 0
            self.state = S_JUMPING

        if(tiles != None):
            self.coll = self.hitbox_wall_coll(tiles)
        if(self.coll == -1):
            return True
        if(self.state == S_BACKING):
            if(self.coll == 0):
                self.state = 0
            self.image.move_x(self.movex * -self.backspeed *dt)
            self.image.move_y(self.movey * -self.backspeed*dt)
        if(self.state == S_JUMPING or self.state == S_QUICADO):
            if(self.shift == False):
                self.shift = True
                nx = self.image.x
                ny = self.image.y
                if(abs(self.movex)>abs(self.movey)):
                    self.image = Sprite("Assets/Sprites/j_horz.png")
                else:
                    self.image = Sprite("Assets/Sprites/j_vert.png")
                self.image.x = nx
                self.image.y = ny
            if(self.coll == 0):
                self.state = S_JUMPING
            self.image.move_x(self.movex*dt)
            self.image.move_y(self.movey*dt)
            
    def player_jump(self, mousex,mousey):
        vel_x = mousex-self.center_x
        vel_y = mousey-self.center_y
        norma = math.sqrt((vel_x*vel_x)+(vel_y*vel_y))
        alpha = (self.jump_speed/norma)
        vel_x *= alpha
        vel_y *= alpha
        self.state = S_JUMPING
        return((vel_x,vel_y))
    def player_enemy_coll(self, enemies = None):
        for e1 in enemies:
            if(self.sbox.collided(e1.image)):
                return True
        return False
    def hitbox_wall_coll(self, tiles = None):
        for t1 in tiles:
            if (self.hitbox.collided(t1.image)):
                self.shift = False
                if(t1.tipo == T_FASE):
                    return -1
                tile_center_x = (t1.image.x + (t1.image.width/2))
                tile_center_y = (t1.image.y + (t1.image.height/2))
                if(t1.tipo == T_BASE or t1.tipo == T_TIRO_CIM or t1.tipo == T_TIRO_DIR or t1.tipo == T_TIRO_BAI or t1.tipo == T_TIRO_ESQ or t1.tipo == T_FASE):
                    self.state = S_BACKING
                    y = 0
                    x = 0
                    x = self.image.x
                    y = self.image.y
                    if(abs(self.center_x-tile_center_x) > abs(self.center_y-tile_center_y)):
                        if(self.center_x>tile_center_x):
                            self.image = Sprite(self.path + "esq" + ".png")
                        else:
                            self.image = Sprite(self.path + "dir" + ".png")
                    else:
                        if(self.center_y>tile_center_y):
                            self.image = Sprite(self.path + "cim" + ".png")
                        else:
                            self.image = Sprite(self.path + "bai" + ".png")
                    self.image.x = x
                    self.image.y = y
                elif(t1.tipo == T_GELO):
                    self.state = S_JUMPING
                    self.movex = 0
                    self.movey = self.jump_speed*self.slide_speed
                    if(self.image.x > t1.image.x):
                        self.image.x = t1.image.x + t1.image.width
                    else:
                        self.image.x = t1.image.x - self.image.width
                elif(t1.tipo == T_MOLA_DIR and self.state == S_JUMPING):
                    new = self.movey * -1
                    self.movey = self.movex
                    self.movex = new
                    self.state = S_QUICADO
                    self.quica_timer = 0
                    self.j_sound.play()
                elif(t1.tipo == T_MOLA_ESQ and self.state == S_JUMPING):
                    new = self.movex * -1
                    self.movex = self.movey
                    self.movey = new
                    self.state = S_QUICADO
                    self.quica_timer = 0
                    self.j_sound.play()
                return 1
        return 0
    def player_draw(self):
        self.image.draw()