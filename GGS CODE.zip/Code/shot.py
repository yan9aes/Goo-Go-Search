from PPlay.sprite import *

class Shot:
    def __init__(self, x, y, vx, vy, imgname = "shot.png", path = "Assets/Sprites/"):
        self.image = Sprite(path + imgname)
        self.image.x = x-self.image.width/2
        self.image.y = y-self.image.height/2
        self.vx = vx
        self.vy = vy
    def update(self, w, h, dt):
        self.image.move_x(self.vx*dt)
        self.image.move_y(self.vy*dt)
        if(self.image.x >= w or self.image.x <= 0):
            return True
        if(self.image.y >= h or self.image.y <= 0):
            return True
        return False