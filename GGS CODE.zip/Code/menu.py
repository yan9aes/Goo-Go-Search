from PPlay.window import*
from PPlay.sprite import*
from PPlay.gameimage import*

MAIN_MENU = 0
RUNNING = 1
OPTIONS = 2
REPEAT_LEVEL = 3
NEXT_LEVEL = 4
TUTORIAL = 5
#Menu
def Mouse_Over(mouse, x0, y0, xf, yf):
    if(x0>xf):
        tmp = x0
        x0 = xf
        xf = tmp
    if(y0>yf):
        tmp = y0
        y0 = yf
        yf = tmp
    mpos = mouse.get_position()
    if((mpos[0]>=x0 and mpos[0]<=xf)and (mpos[1]>=y0 and mpos[1]<=yf)):
        return True
    return False
def Main_Menu(tela, mouse, tela_w, tela_h, is_goo = True):
    if(is_goo):
        goo = Sprite("Assets/Sprites/goo_idle_0.png")
    else:
        goo = Sprite("Assets/Sprites/goo_idle_1.png")
    banner = Sprite("Assets/Sprites/banner.png")
    fundo = GameImage("Assets/Sprites/bg_menu.png")
    options = Sprite("Assets/Sprites/options_0.png")
    tut = Sprite("Assets/Sprites/tut_0.png")
    jogar = Sprite("Assets/Sprites/play_0.png")
    sair = Sprite("Assets/Sprites/quit_0.png")
    options.x = tela_w/2 - options.width/2
    jogar.x = tela_w/2 - jogar.width/2
    sair.x = tela_w/2 - sair.width/2
    tut.x = tela_w/2 - tut.width/2
    
    tut.y = 0.55*tela_h - jogar.height/2
    banner.y = 0.2*tela_h - banner.height/2
    banner.x = 0.5*tela_w - banner.width/2
    options.y = 0.7*tela_h - options.height/2
    jogar.y = 0.4*tela_h - jogar.height/2
    sair.y = 0.9*tela_h - sair.height/2
    
    goo.x = banner.x + banner.width*0.32
    goo.y = banner.y - goo.height/2
    if(Mouse_Over(mouse, options.x, options.y, (options.x+options.width), (options.y+options.height))):
        options = Sprite("Assets/Sprites/options_1.png")
        options.y = 0.7*tela_h - options.height/2
        options.x = tela_w/2 - options.width/2
    if(Mouse_Over(mouse, tut.x, tut.y, (tut.x+options.width), (tut.y+tut.height))):
        tut = Sprite("Assets/Sprites/tut_1.png")
        tut.y = 0.55*tela_h - tut.height/2
        tut.x = tela_w/2 - tut.width/2
    if(Mouse_Over(mouse, jogar.x, jogar.y, (jogar.x+jogar.width), (jogar.y+jogar.height))):
        jogar = Sprite("Assets/Sprites/play_1.png")
        jogar.y = 0.4*tela_h - jogar.height/2
        jogar.x = tela_w/2 - jogar.width/2
    if(Mouse_Over(mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
        sair = Sprite("Assets/Sprites/quit_1.png")
        sair.y = 0.9*tela_h - sair.height/2
        sair.x = tela_w/2 - sair.width/2
    
    tela.set_background_color((0,0,0))
    fundo.draw()
    options.draw()
    jogar.draw()
    sair.draw()
    tut.draw()
    banner.draw()
    goo.draw()
    tela.update()
    if(Mouse_Over(mouse, options.x, options.y, (options.x+options.width), (options.y+options.height))):
        if(mouse.is_button_pressed(1)):
            return OPTIONS
    if(Mouse_Over(mouse, jogar.x, jogar.y, (jogar.x+jogar.width), (jogar.y+jogar.height))):
        if(mouse.is_button_pressed(1)):
            return REPEAT_LEVEL
    if(Mouse_Over(mouse, tut.x, tut.y, (tut.x+options.width), (tut.y+tut.height))):
        if(mouse.is_button_pressed(1)):
            return TUTORIAL
    if(Mouse_Over(mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
        if(mouse.is_button_pressed(1)):
            return -1
    
    return 0
