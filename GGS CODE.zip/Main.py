from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

from PPlay.window import *
from PPlay.gameimage import *
from PPlay.sprite import *
from Code.hunter import *
from Code.tile import*
from Code.Goo import *
from Code.menu import *

MAIN_MENU = 0
RUNNING = 1
OPTIONS = 2
REPEAT_LEVEL = 3
NEXT_LEVEL = 4
TUTORIAL = 5
ENDING = 9

MAX_LEVEL = 6

HEIGHT = 640
WIDTH = 960
M_VOLUME = 60

class App:
    def __init__(self):
        self.d_sound = Sound("Assets/Sounds/death.ogg")
        self.nl_sound = Sound("Assets/Sounds/next_level.ogg")
        self.sound_vol = 0
        self.menu_music = Sound("Assets/Sounds/main_track.ogg")
        self.play_music = Sound("Assets/Sounds/back_track.ogg")
        self.menu_music.set_repeat(True)
        self.play_music.set_repeat(True)
        self.play_music.set_volume(M_VOLUME)
        self.janela = Window(WIDTH,HEIGHT)
        self.janela.set_title("Goo Go Search")
        self.keyboard = self.janela.get_keyboard()
        self.mouse = self.janela.get_mouse()
        self.jogador = Player(WIDTH/2,HEIGHT/2, self.sound_vol*100)
        self.state = MAIN_MENU
        self.back_tiles = []
        self.tiles = []
        self.hunters = []
        self.bullets = []
        self.matriz_level = []
        self.curr_level = 1
        self.menu_goo = True
        self.menu_timer = 0.1
        self.sound_cool = 0.0
        self.first = True
        self.Load_Data()
    def Load_Level(self):
        self.back_tiles.clear()
        self.tiles.clear()
        self.matriz_level.clear()
        level = open("Assets/Levels/level_"+str(self.curr_level)+".txt")
        i = 0
        tmp = level.readline()
        while(tmp != ''):
            self.matriz_level.append(tmp)
            for j in range(len(tmp)):
                if tmp[j] == '0':
                    self.back_tiles.append(Sprite("Assets/Sprites/tiles_0.png"))
                    self.back_tiles[-1].x = (j-1)*32
                    self.back_tiles[-1].y = (i-1)*32
                elif tmp[j] == '1':
                    self.tiles.append(Tile(1))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == '2':
                    self.tiles.append(Tile(2))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == '3':
                    self.back_tiles.append(Sprite("Assets/Sprites/tiles_0.png"))
                    self.back_tiles[-1].x = (j-1)*32
                    self.back_tiles[-1].y = (i-1)*32
                    self.tiles.append(Tile(3))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == '9':
                    self.back_tiles.append(Sprite("Assets/Sprites/tiles_0.png"))
                    self.back_tiles[-1].x = (j-1)*32
                    self.back_tiles[-1].y = (i-1)*32
                    self.tiles.append(Tile(9))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == '4' or tmp[j] == '5' or tmp[j] == '6' or tmp[j] == '7':
                    self.back_tiles.append(Sprite("Assets/Sprites/tiles_0.png"))
                    self.back_tiles[-1].x = (j-1)*32
                    self.back_tiles[-1].y = (i-1)*32
                    self.tiles.append(Tile(int(tmp[j]), self.sound_vol*100))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == '8':
                    self.tiles.append(Tile(8))
                    self.tiles[-1].image.x = (j-1)*32
                    self.tiles[-1].image.y = (i-1)*32
                elif tmp[j] == 's':
                    self.back_tiles.append(Sprite("Assets/Sprites/tiles_0.png"))
                    self.back_tiles[-1].x = (j-1)*32
                    self.back_tiles[-1].y = (i-1)*32
                    self.jogador= Player((j-1)*32, (i-1)*32, self.sound_vol*100)
            i+=1
            tmp = level.readline()
        level.close()
        self.Load_Enemies()
    def Load_Enemies(self):
        self.hunters.clear()
        self.bullets.clear()
        level = open("Assets/Levels/enemies_"+str(self.curr_level)+".txt")
        tmp = level.readline()
        while(tmp != ''):
            lst = tmp.split()
            if(lst[0] == '1'):
                aux = []
                auy = []
                for i in range(int(lst[3])):
                    aux.append(int(lst[4+(i*2)]))
                    auy.append(int(lst[5+(i*2)]))
                self.hunters.append(Hunter(int(lst[1]), int(lst[2]), aux[:], auy[:], self.sound_vol*100))
            elif(lst[0] == '2'):
                ct = 0
                i = 0
                while ct < int(lst[1]):
                    if i < len(self.tiles):
                        if(self.tiles[i].tipo >3 and self.tiles[i].tipo < 8):
                            ct+=1
                        i+=1
                self.tiles[i-1].timer = float(lst[2])
            tmp = level.readline()
        level.close()
            
    def Play(self):
        ALIVE = True
        if(self.keyboard.key_pressed("ESC")):
            self.Level_Clear()
            return MAIN_MENU
        if(self.state == NEXT_LEVEL):
            self.nl_sound.play()
            self.curr_level +=1
            self.state = REPEAT_LEVEL
            self.Save_Data()
            if(self.curr_level > MAX_LEVEL):
                self.curr_level = 1
                self.Save_Data()
                return ENDING
        if(self.state == REPEAT_LEVEL):
            ALIVE = True
            self.Load_Level()
            self.Load_Enemies()
            self.state = RUNNING
        if(ALIVE):
            dt = self.janela.delta_time()
            for i in range(len(self.hunters)):
                self.hunters[i].update(self.jogador.center_x, self.jogador.center_y, dt, self.bullets)
            for i in range(len(self.tiles)):
                self.tiles[i].update(dt, self.bullets)
            if(self.jogador.player_enemy_coll(self.hunters)):
                self.Level_Clear()
                self.d_sound.play()
                return REPEAT_LEVEL
            if(self.jogador.player_enemy_coll(self.bullets)):
                self.Level_Clear()
                self.d_sound.play()
                return REPEAT_LEVEL
            if(self.jogador.player_update(self.mouse, self.keyboard, dt, self.tiles) == True):
                self.Level_Clear()
                return NEXT_LEVEL
            tmp = 0
                    
            self.janela.set_background_color((0,0,0))
            for i in range(len(self.back_tiles)):
                self.back_tiles[i].draw()
            for i in range(len(self.tiles)):
                self.tiles[i].image.draw()
            for i in range(len(self.hunters)):
                self.hunters[i].image.draw()
            self.jogador.player_draw()
            while(len(self.bullets)>tmp):
                if(self.bullets[tmp].update(WIDTH, HEIGHT, dt)):
                    self.bullets.pop(tmp)
                    tmp-= 1
                else:
                    self.bullets[tmp].image.draw()
                tmp+=1
            self.janela.update()
            return RUNNING
        return REPEAT_LEVEL
    def Main_Menu(self):
        if(self.menu_timer<=0):
            self.menu_goo = not(self.menu_goo)
            self.menu_timer = 0.1
        self.menu_timer-=self.janela.delta_time()
        return Main_Menu(self.janela, self.mouse, WIDTH, HEIGHT, self.menu_goo)
    
    def Options(self):
        fundo = GameImage("Assets/Sprites/bg_menu.png")
        som = Sprite("Assets/Sprites/bt_som.png")
        sair = Sprite("Assets/Sprites/quit_0.png")
        if(self.sound_vol != 0):
            som_switch = Sprite("Assets/Sprites/bt_on_0.png")
        else:
            som_switch = Sprite("Assets/Sprites/bt_off_0.png")
        som.x = WIDTH*0.3 - som.width/2
        som.y = HEIGHT*0.5 - som.height/2
        som_switch.x = WIDTH*0.7 - som_switch.width/2
        som_switch.y = HEIGHT*0.5 - som_switch.height/2
        sair.x = WIDTH/2 - sair.width/2
        sair.y = 0.8*HEIGHT - sair.height/2
        if(Mouse_Over(self.mouse, som_switch.x, som_switch.y, (som_switch.x+som_switch.width), (som_switch.y+som_switch.height))):
            self.sound_cool -= self.janela.delta_time()
            if(self.sound_vol != 0):
                som_switch = Sprite("Assets/Sprites/bt_on_1.png")
            else:
                som_switch = Sprite("Assets/Sprites/bt_off_1.png")
            som_switch.x = WIDTH*0.7 - som_switch.width/2
            som_switch.y = HEIGHT*0.5 - som_switch.height/2
            if(self.mouse.is_button_pressed(1) and self.sound_cool <=0):
                self.sound_vol = abs(self.sound_vol-1)
                self.sound_cool = 0.2
        if(Mouse_Over(self.mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
            sair = Sprite("Assets/Sprites/quit_1.png")
            sair.y = 0.8*HEIGHT - sair.height/2
            sair.x = WIDTH/2 - sair.width/2
            if(self.mouse.is_button_pressed(1)):
                self.state = MAIN_MENU
        if(self.keyboard.key_pressed("ESC")):
            self.state = MAIN_MENU
        self.janela.set_background_color((0,0,0))
        fundo.draw() 
        som.draw()
        som_switch.draw()
        sair.draw()
        self.janela.update()
    def Tutorial(self):
        fundo = GameImage("Assets/Sprites/bg_menu.png")
        tut = Sprite("Assets/Sprites/tut.png")
        sair = Sprite("Assets/Sprites/quit_0.png")
        tut.x = WIDTH*0.5 - tut.width/2
        tut.y = HEIGHT*0.1
        sair.x = WIDTH/2 - sair.width/2
        sair.y = 0.8*HEIGHT - sair.height/2
        if(Mouse_Over(self.mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
            sair = Sprite("Assets/Sprites/quit_1.png")
            sair.y = 0.8*HEIGHT - sair.height/2
            sair.x = WIDTH/2 - sair.width/2
            if(self.mouse.is_button_pressed(1)):
                self.state = MAIN_MENU
        if(self.keyboard.key_pressed("ESC")):
            self.state = MAIN_MENU
        self.janela.set_background_color((0,0,0))
        fundo.draw() 
        tut.draw()
        sair.draw()
        self.janela.update()
        
    def Game_Loop(self):
        if(self.first == True):
            self.menu_music.play()
            self.Intro()
            self.first = False
        while self.state != -1:
            self.d_sound.set_volume(self.sound_vol*100)
            self.nl_sound.set_volume(self.sound_vol*100)
            self.menu_music.set_volume(self.sound_vol*M_VOLUME)
            self.play_music.set_volume(self.sound_vol*M_VOLUME)
            if(self.state == MAIN_MENU):
                self.play_music.stop()
                if(self.menu_music.is_playing() == False):
                    self.menu_music.play()
                self.state = self.Main_Menu()
                if(self.state == RUNNING or self.state == REPEAT_LEVEL or self.state == NEXT_LEVEL):
                    self.menu_music.stop()
                    self.play_music.play()
            if(self.state == ENDING):
                self.play_music.stop()
                if(self.menu_music.is_playing() == False):
                    self.menu_music.play()
                    self.Save_Data()
                self.Ending()
            if(self.state == RUNNING or self.state == REPEAT_LEVEL or self.state == NEXT_LEVEL):
                self.state = self.Play()
                if(self.state == MAIN_MENU):
                    self.play_music.stop()
                    self.menu_music.play()
            if(self.state == OPTIONS):
                self.play_music.stop()
                self.Options()
                self.Save_Data()
            if(self.state == TUTORIAL):
                self.Tutorial()
        self.janela.close()
    def Level_Clear(self):
        self.back_tiles.clear()
        self.tiles.clear()
        self.matriz_level.clear()
        self.hunters.clear()
        self.bullets.clear()
    def Load_Data(self):
        data = open("Assets/Levels/save.txt")
        tmp = data.readline()
        lst = tmp.split()
        if(len(tmp) >= 2):
            self.curr_level = int(lst[0])
            self.sound_vol = int(lst[1])
        data.close()
    def Save_Data(self):
        data = open("Assets/Levels/save.txt", "w+")
        out = str(self.curr_level)+" "+ str(self.sound_vol)
        data.write(out)
        data.close()
    def Intro(self):
        intro = Sprite("Assets/Sprites/itxt.png")
        intro.x = WIDTH/2-(intro.width/2)
        intro.y = HEIGHT
        while(intro.y+intro.height >0):
            if(self.keyboard.key_pressed("ESC")):
                break
            dt = self.janela.delta_time()
            intro.y-=(100*dt)
            self.janela.set_background_color((0,0,0))
            intro.draw()
            self.janela.update()
    def Ending(self):
        if(self.menu_timer<=0):
            self.menu_goo = not(self.menu_goo)
            self.menu_timer = 0.1
        self.menu_timer-=self.janela.delta_time()
        if(self.menu_goo):
            goo = Sprite("Assets/Sprites/goo_idle_0.png")
        else:
            goo = Sprite("Assets/Sprites/goo_idle_1.png")
        banner = Sprite("Assets/Sprites/banner.png")
        fundo = GameImage("Assets/Sprites/bg_menu.png")
        sair = Sprite("Assets/Sprites/quit_0.png")
        yjb = Sprite("Assets/Sprites/yjb.png")
        cgt = Sprite("Assets/Sprites/cgt.png")
        cgt.x= WIDTH/2 - cgt.width/2
        yjb.x= WIDTH/2 - yjb.width/2
        sair.x = WIDTH/2 - sair.width/2
        sair.y = 0.8*HEIGHT - sair.height/2
        cgt.y = HEIGHT*0.05
        yjb.y = HEIGHT*0.3
        banner.y = 0.6*HEIGHT - banner.height/2
        banner.x = 0.5*WIDTH - banner.width/2
        
        goo.x = banner.x + banner.width*0.32
        goo.y = banner.y - goo.height/2
        if(Mouse_Over(self.mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
            sair = Sprite("Assets/Sprites/quit_1.png")
            sair.y = 0.8*HEIGHT - sair.height/2
            sair.x = WIDTH/2 - sair.width/2
        
        self.janela.set_background_color((0,0,0))
        fundo.draw()
        banner.draw()
        goo.draw()
        cgt.draw()
        yjb.draw()
        sair.draw()
        self.janela.update()
        if(Mouse_Over(self.mouse, sair.x, sair.y, (sair.x+sair.width), (sair.y+sair.height))):
            if(self.mouse.is_button_pressed(1)):
                self.state = MAIN_MENU
        if(self.keyboard.key_pressed("ESC")):
            self.state = MAIN_MENU
#Main
jogo = App()
jogo.Game_Loop()